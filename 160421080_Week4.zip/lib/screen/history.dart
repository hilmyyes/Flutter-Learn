
import 'package:flutter/material.dart';

class History extends StatelessWidget {
 @override
 Widget build(BuildContext context) {
  return Scaffold(
   appBar: AppBar(
    title: Text('History'),
    backgroundColor: Colors.indigoAccent,
   ),
   backgroundColor: Colors.cyanAccent,
   body: Center(
  child: Text("This is History "),
   ),
  );
 }
}
